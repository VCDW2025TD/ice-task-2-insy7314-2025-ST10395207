# JWT Research

JSON Web Token (JWT) is a compact token format used to securely transmit information between parties. JWTs are essential for web apps to authenticate users without storing session data on the server. JWTs are sent in HTTP headers (Authorization: Bearer <token>) to validate requests. If misused, JWTs can be stolen or manipulated, leading to breaches. A real-world example is the 2020 Auth0 leak, where improper token handling could allow unauthorized access. JWTs increase security and scalability when implemented correctly.
