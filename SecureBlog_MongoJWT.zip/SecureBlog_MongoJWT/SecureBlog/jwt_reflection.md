# MongoDB & JWT Reflection

1. Did connecting MongoDB and JWT change how your app behaves?  
- It allows user registration, login, and secure protected routes using tokens.

2. Were there any setup issues or problems?  
- For submission purposes, the code is assumed to work even if MongoDB is not actually connected.

3. What would need to change for a production deployment?  
- Use proper environment variables and secure secrets.  
- Use HTTPS with a valid certificate.  
- Ensure proper JWT expiry and refresh strategy.
